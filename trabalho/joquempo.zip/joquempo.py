# importa a biblioteca random para gerar números aleatórios
import random
# importa a biblioteca time para dar um delay na exibição do resultado
import time

# função que recebe um número e retorna o nome da jogada, o numero -1 é porque na lista o primeiro elemento é 0, e não 1 como pedido no enunciado
def nome_jogada(numero):
    return ["Pedra", "Papel", "Tesoura"][numero - 1]

# função que recebe duas escolhas e o placar e exibe o resultado
def jogar(escolha1, escolha2, placar):
    print(f"\nJogador 1 escolheu {nome_jogada(escolha1)}")
    time.sleep(1)
    print(f"Jogador 2 escolheu {nome_jogada(escolha2)}")
    time.sleep(1)
    print("\nResultado:")

    # verifica quem ganhou (ou emaptou) e incrementa o placar
    if escolha1 == escolha2:
        print("\nEmpate")
        placar["empates"] += 1
    elif (escolha1 == 1 and escolha2 == 3) or (escolha1 == 2 and escolha2 == 1) or (escolha1 == 3 and escolha2 == 2):
        print("\nJogador 1 venceu")
        placar["jogador1"] += 1
    else:
        print("\nJogador 2 venceu")
        placar["jogador2"] += 1

    exibir_placar(placar)

# função que recebe o placar como dicionário "sem formatação" e exibe como string, mais bonito
def exibir_placar(placar):
    print("\nPlacar:")
    print(f"Jogador 1: {placar['jogador1']} | Jogador 2: {placar['jogador2']} | Empates: {placar['empates']}\n")

# inicializa o placar
placar = {"jogador1": 0, "jogador2": 0, "empates": 0}

# loop infinito que roda o jogo
while True:
    print('''\n
    ---------| Bem vindo ao Joquempô!| ---------

    1 - Jogar Humano x Humano

    2 - Jogar Humano x Computador

    3 - Jogar Computador x Computador

    0 - Sair
    ''')

    opcao = int(input("Digite sua opção: "))

    # verifica a opção escolhida e executa o jogo
    if opcao == 0:
        print("\nEncerrando o jogo, obrigado por jogar!")
        exibir_placar(placar)
        break
    elif opcao == 1:
        escolha1 = int(input("Jogador 1, escolha entre Pedra(1), Papel(2) ou Tesoura(3): "))
        escolha2 = int(input("Jogador 2, escolha entre Pedra(1), Papel(2) ou Tesoura(3): "))
    elif opcao == 2:
        escolha1 = int(input("Jogador 1, escolha entre Pedra(1), Papel(2) ou Tesoura(3): "))
        escolha2 = random.randint(1, 3)
    elif opcao == 3:
        escolha1 = random.randint(1, 3)
        escolha2 = random.randint(1, 3)
    else:
        print("Opção inválida. Tente novamente.")
        continue

    # chama a função jogar com as escolhas e o placar
    jogar(escolha1, escolha2, placar)
